﻿var string = "'How you doin'?', Joey said.";
console.log(string);

var escString = '\'How you doin\'?\', Joey said.';
console.log(escString);