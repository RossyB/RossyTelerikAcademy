﻿var intNumber = 69;
console.log(typeof(intNumber));

var floatNumber = 45.87;
console.log(typeof(floatNumber));

var boolflag = true;
console.log(typeof(boolflag));

var firstName = 'Pesho';
console.log(typeof(firstName));

var arr = [5, 15, 25, 30];
console.log(typeof(arr));

var obj = {};
obj.Name = 'Pesho';
obj.Age = 28;
console.log(typeof(obj));