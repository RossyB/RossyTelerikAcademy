﻿var intNumber = 69;
console.log('Integer litaral: ' + intNumber);

var floatNumber = 45.87;
console.log('Floating point literal: ' + floatNumber);

var boolflag = true;
console.log('bollean literal: ' + boolflag);

var firstName = 'Pesho';
var lastName = 'Peshev';
console.log('String literal: ' + firstName + ' ' + lastName);

var arr = [5, 15, 25, 30];
console.log('Array literal: ' + arr);

var obj = {};
obj.Name = 'Pesho';
obj.Age = 28;
console.log('Object literal: ' + obj.Name + ' ' + obj.Age);