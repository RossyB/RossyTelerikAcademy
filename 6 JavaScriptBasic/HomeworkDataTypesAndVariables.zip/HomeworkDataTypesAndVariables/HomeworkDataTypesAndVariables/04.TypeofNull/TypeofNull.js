﻿var nullVar = null;
console.log(typeof (nullVar))

var undefinedVar;
console.log(typeof (undefinedVar))