# Code Documentation and Comments
## Homework

### Task 1. Code documentation
*	Open project located in `StringExtensions.csproj` and:
	*	Add comments where necessary.
	*	For each public member add documentation as C# XML Documentation Comments
	*	* Play with Sandcastle / other tools and try to generate CHM book
